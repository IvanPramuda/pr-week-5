class Pendaftar {
    constructor(nama, umur, uangSangu) {
        this.nama = nama;
        this.umur = umur;
        this.uangSangu = uangSangu;
    }
    
}

const pendaftarList = [];
const registrationForm = document.getElementById('registrationForm');
const pendaftarTable = document.getElementById('pendaftarTable');
const pendaftarListElem = document.getElementById('pendaftarList');
const resumeElem = document.getElementById('resume');

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    if (tabName !== 'backToRegistration') {
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }
}

function submitForm() {
    const nama = document.getElementById('nama').value;
    const umur = parseInt(document.getElementById('umur').value);
    const uangSangu = parseInt(document.getElementById('uangSangu').value);

    if (nama.length < 10 || umur < 25 || uangSangu < 100000 || uangSangu > 1000000) {
        alert("Data tidak valid. Pastikan nama memiliki minimal 10 karakter, umur minimal 25 tahun, dan uang sangu antara 100 ribu hingga 1 juta.");
        return;
    }

    const pendaftar = new Pendaftar(nama, umur, uangSangu);
    pendaftarList.push(pendaftar);

    updateTable();
    updateResume();

    registrationForm.reset();

    document.getElementById('listPendaftarTab').click();
}

function updateTable() {
    const pendaftarTable = document.getElementById('pendaftarTable');
    const pendaftarListElem = document.getElementById('pendaftarList');

    while (pendaftarListElem.firstChild) {
        pendaftarListElem.removeChild(pendaftarListElem.firstChild);
    }

    pendaftarList.forEach((pendaftar) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${pendaftar.nama}</td>
            <td>${pendaftar.umur}</td>
            <td>${pendaftar.uangSangu}</td>
        `;
        pendaftarListElem.appendChild(row);
    });

    pendaftarTable.style.display = pendaftarList.length > 0 ? "table" : "none";
}

function goBackToRegistration() {
    openTab(event, 'registrasi');
}

function updateResume() {
    const totalUmur = pendaftarList.reduce((sum, pendaftar) => sum + pendaftar.umur, 0);
    const totalUangSangu = pendaftarList.reduce((sum, pendaftar) => sum + pendaftar.uangSangu, 0);
    const rataRataUmur = pendaftarList.length > 0 ? totalUmur / pendaftarList.length : 0;
    const rataRataUangSangu = pendaftarList.length > 0 ? totalUangSangu / pendaftarList.length : 0;

    resumeElem.innerHTML = `Rata-rata pendaftar memiliki uang saku sebesar ${rataRataUangSangu} dengan rata-rata umur ${rataRataUmur}`;
}
